0.1
======================
1. import from eim account

0.2
=========
1. 代码结构优化

0.3
=========
1. 加入圣诞图片

0.4
=========
1. bug fix. 从登陆页面获取号码出错，因为页面改动了

0.5
=======
1. 将manifest.json中的./->/ https://code.google.com/p/chromium/issues/detail?id=437675

0.6
=======
1. 加入storage.sync api
